# EdgeTelemetry Deployment

Simple production deployment for EdgeTelemetry system on Ubuntu.

## Requirements
- Ubuntu 24.04.1 LTS
- Docker 27.5+
- Docker Compose 1.29+
- Make utility

## Quick Deploy

### 1. Clone and Navigate
```bash
git clone https://github.com/NCG-Africa/EdgeTelemetryDeployment.git
cd EdgeTelemetryDeployment
```

### 2. Configure Database
```bash
# Edit with your database settings
nano configs/processor-config.env
```

Update these values:
```bash
MSSQL_SERVER=your-db-server
MSSQL_DATABASE=your-database
MSSQL_USERNAME=your-username
MSSQL_PASSWORD=your-password
MSSQL_PORT=1433
```

### 3. Deploy
```bash
make prod-deploy
```

### 4. Monitor
```bash
# Real-time monitoring
make monitor

# OR view logs
make prod-logs
```

## Service URLs
After deployment:
- **Collector API**: http://localhost:8001
- **Processor API**: http://localhost:8002  
- **Kafka UI**: http://localhost:8080

## Common Commands
```bash
make help           # Show all commands
make health         # Check service health
make status         # Show service status
make prod-restart   # Restart services
make prod-down      # Stop services
make test-deployment # Test with sample data
```

## Test Your Deployment
```bash
# Send test data
curl -X POST http://localhost:8001/telemetry \
  -H "Content-Type: application/json" \
  -d '{
    "type": "telemetry-batch",
    "events": [{
      "type": "metric",
      "metricName": "test_metric", 
      "value": 100,
      "timestamp": "2024-01-01T12:00:00Z",
      "attributes": {
        "app.name": "TestApp",
        "user.id": "test-user"
      }
    }],
    "batch_size": 1,
    "timestamp": "2024-01-01T12:00:00Z"
  }'

# OR use built-in test
make test-deployment
```

## Troubleshooting

**Processor unhealthy?**
```bash
make prod-logs-processor
```

**Database connection issues?**
```bash
# Check config
cat configs/processor-config.env

# Check processor logs
make prod-logs-processor | grep -i database
```

**Port conflicts?**
Edit `docker-compose.prod.yml` to change ports.

## System Architecture
```
Client → Collector (8001) → Kafka → Processor (8002) → Database
```

That's it! 🚀