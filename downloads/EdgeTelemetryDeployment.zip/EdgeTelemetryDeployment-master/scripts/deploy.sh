#!/bin/bash
set -e

echo "🚀 Deploying Edge Telemetry System..."

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker first."
    exit 1
fi

# Check if required files exist
if [ ! -f "docker-compose.prod.yml" ]; then
    echo "❌ docker-compose.prod.yml not found!"
    exit 1
fi

if [ ! -f "configs/processor-config.env" ]; then
    echo "❌ configs/processor-config.env not found!"
    echo "Please configure your database settings first."
    echo "Copy configs/processor-config.env.example to configs/processor-config.env and update values."
    exit 1
fi

# Build and start services
echo "🔨 Building and starting services..."
docker-compose -f docker-compose.prod.yml up -d --build

# Wait for services to start
echo "⏳ Waiting for services to start..."
sleep 30

# Run health check
echo "🔍 Running health checks..."
if [ -f "scripts/health-check.sh" ]; then
    ./scripts/health-check.sh
else
    echo "⚠️  Health check script not found, checking manually..."

    # Basic health checks
    if curl -f -s "http://localhost:8001/health" > /dev/null; then
        echo "✅ Telemetry Collector is healthy"
    else
        echo "❌ Telemetry Collector is not responding"
    fi

    if curl -f -s "http://localhost:8002/health" > /dev/null; then
        echo "✅ Telemetry Processor is healthy"
    else
        echo "❌ Telemetry Processor is not responding"
    fi
fi

echo ""
echo "✅ Deployment completed successfully!"
echo ""
echo "📊 Service URLs:"
echo "   Collector API: http://localhost:8001"
echo "   Processor API: http://localhost:8002"
echo "   Collector Health: http://localhost:8001/health"
echo "   Processor Health: http://localhost:8002/health"
echo ""
echo "🔧 Management Commands:"
echo "   View logs: docker-compose -f docker-compose.prod.yml logs -f"
echo "   Stop system: docker-compose -f docker-compose.prod.yml down"
echo "   Check status: docker-compose -f docker-compose.prod.yml ps"
echo "   Restart: docker-compose -f docker-compose.prod.yml restart"
echo ""
echo "📋 Test the system:"
echo "   curl http://localhost:8001/health"
echo "   curl http://localhost:8002/health"