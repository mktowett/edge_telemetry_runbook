# EdgeTelemetry Deployment

Production-ready deployment for EdgeTelemetry system with Kafka, Redis caching, dashboard API, and web portal frontend.

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│                 │    │                 │    │                 │    │                 │
│ Client Apps     │───▶│ Telemetry       │───▶│     Kafka       │───▶│ Telemetry       │───▶│ MSSQL Database  │
│                 │    │ Collector       │    │   (Message      │    │ Processor       │    │                 │
│                 │    │ (Port: 8001)    │    │    Broker)      │    │ (Port: 8002)    │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
                                                      │                                              ▲
                                                      ▼                                              │
                                               ┌─────────────────┐                                   │
                                               │                 │                                   │
                                               │   Kafka UI      │                                   │
                                               │ (Port: 8080)    │                                   │
                                               │                 │                                   │
                                               └─────────────────┘                                   │
                                                                                                     │
                              ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐      │
                              │                 │    │                 │    │                 │      │
                              │ EdgeRum Portal  │◀───│ Dashboard API   │◀───│ Redis Cache     │      │
                              │ (Port: 8004)    │    │ (Port: 8003)    │    │ (Port: 6379)    │      │
                              │                 │    │                 │    │                 │      │
                              └─────────────────┘    └─────────────────┘    └─────────────────┘      │
                                                              │                                       │
                                                              └───────────────────────────────────────┘
```

## Components

- **Telemetry Collector**: REST API that receives telemetry data and publishes to Kafka
- **Telemetry Processor**: Consumes telemetry data from Kafka and stores in database
- **Dashboard API**: REST API for querying telemetry data with Redis caching
- **EdgeRum Portal**: Web frontend dashboard for data visualization and monitoring
- **Redis Cache**: High-performance caching layer for dashboard queries
- **Kafka**: Message broker ensuring reliable data flow
- **Zookeeper**: Kafka cluster coordination service
- **Kafka UI**: Web interface for monitoring topics, messages, and consumer groups

## Quick Deployment

### Prerequisites
- Ubuntu 24.04.1 LTS (or compatible)
- Docker 27.5+
- Docker Compose 1.29+
- Make utility
- Access to MSSQL database

### 1. Clone Repository
```bash
git clone https://github.com/NCG-Africa/EdgeTelemetryDeployment.git
cd EdgeTelemetryDeployment
```

### 2. Configure Database
```bash
# Copy example configuration
cp configs/processor-config.env.example configs/processor-config.env

# Edit with your database settings
nano configs/processor-config.env
```

Required configuration:
```bash
MSSQL_SERVER=your-db-server
MSSQL_DATABASE=your-database
MSSQL_USERNAME=your-username
MSSQL_PASSWORD=your-password
MSSQL_PORT=1433
```

### 3. Deploy
```bash
make prod-deploy
```

### 4. Access Services
After successful deployment, open your browser to access the dashboard:
- **EdgeRum Portal**: http://localhost:8004

### 5. Monitor
```bash
# Real-time monitoring dashboard
make monitor

# OR view logs
make prod-logs
```

## Service URLs

After successful deployment:
- **EdgeRum Portal (Frontend)**: http://localhost:8004
- **Collector API**: http://localhost:8001
- **Processor API**: http://localhost:8002  
- **Dashboard API**: http://localhost:8003
- **Kafka UI**: http://localhost:8080
- **Redis**: localhost:6379
- **Health Checks**: 
  - http://localhost:8001/health
  - http://localhost:8002/health
  - http://localhost:8003/health
  - http://localhost:8004/health

## Management Commands

### Deployment
```bash
make prod-deploy     # Deploy/redeploy system
make prod-down       # Stop all services
make prod-restart    # Restart services
make prod-update     # Update to latest images
```

### Monitoring
```bash
make health          # Quick health check
make health-detailed # Detailed health with database status
make status          # Show all service status
make monitor         # Real-time monitoring dashboard
```

### Logs
```bash
make prod-logs                # All service logs
make prod-logs-collector      # Collector logs only
make prod-logs-processor      # Processor logs only
make prod-logs-api           # Dashboard API logs only
make prod-logs-portal        # Portal frontend logs only
make prod-logs-redis         # Redis logs only
make logs-kafka              # Kafka logs
```

### Testing
```bash
make test-deployment    # Send test telemetry data
make test-api          # Test Dashboard API endpoints
make test-portal       # Test Portal frontend
make test-full         # Complete integration test
make config-check      # Validate configuration
```

### Portal Operations
```bash
make portal-open       # Open portal in browser
make portal-dev        # Start portal in development mode
make portal-scale      # Scale portal for load testing
```

### Service-Specific Operations
```bash
make prod-restart-api      # Restart Dashboard API only
make prod-restart-portal   # Restart Portal only
make prod-restart-redis    # Restart Redis cache only
```

### Maintenance
```bash
make backup         # Backup Kafka and Redis data
make cleanup        # Clean unused resources
make clean          # Stop and remove everything
```

## Testing Your Deployment

### Built-in Tests
```bash
make test-deployment    # Test data collection and processing
make test-api          # Test Dashboard API endpoints
make test-portal       # Test Portal frontend
make test-full         # Complete integration test
```

### Manual Data Collection Test
```bash
curl -X POST http://localhost:8001/telemetry \
  -H "Content-Type: application/json" \
  -d '{
    "type": "telemetry-batch",
    "events": [{
      "type": "metric",
      "metricName": "test_metric", 
      "value": 100,
      "timestamp": "2024-01-01T12:00:00Z",
      "attributes": {
        "app.name": "TestApp",
        "app.version": "1.0.0",
        "user.id": "test-user-123",
        "device.platform": "test"
      }
    }],
    "batch_size": 1,
    "timestamp": "2024-01-01T12:00:00Z"
  }'
```

### Manual Dashboard API Test
```bash
# Health check
curl http://localhost:8003/health

# Future API endpoints (when implemented):
# curl http://localhost:8003/api/v1/telemetry
# curl http://localhost:8003/api/v1/metrics
# curl http://localhost:8003/api/v1/devices
```

### Manual Portal Test
```bash
# Check portal availability
curl http://localhost:8004

# Or open in browser
make portal-open
```

## Troubleshooting

### Common Issues

**Services unhealthy after deployment?**
- The system includes auto-recovery that restarts services if timing issues occur
- Monitor the deployment output for "🔄 [Service] unhealthy - applying automatic fix..."

**Portal not loading?**
```bash
# Check portal status
make test-portal

# Check portal logs
make prod-logs-portal

# Restart portal
make prod-restart-portal
```

**Database connection issues?**
```bash
# Check configuration
cat configs/processor-config.env

# Check service logs for database errors
make prod-logs-processor | grep -i database
make prod-logs-api | grep -i database
```

**Redis connection issues?**
```bash
# Check Redis status
docker exec -it telemetry-redis redis-cli ping

# Check API logs for cache errors
make prod-logs-api | grep -i redis
```

**Port conflicts?**
```bash
# Check what's using the ports
sudo netstat -tulpn | grep -E ':(8001|8002|8003|8004|8080|6379)'

# Edit docker-compose.prod.yml to change port mappings if needed
```

**View detailed service status:**
```bash
make health-detailed
```

### Log Analysis
```bash
# Search for errors across all services
make prod-logs | grep -i "error\|exception\|failed"

# Monitor Kafka connectivity
make prod-logs | grep -i "kafka"

# Check database operations
make prod-logs-processor | grep -i "database\|sql"
make prod-logs-api | grep -i "database\|sql"

# Check Redis cache operations
make prod-logs-api | grep -i "cache\|redis"

# Check portal connectivity
make prod-logs-portal | grep -i "api\|connection"
```

## Production Features

✅ **Auto-Recovery**: Automatic service restart for timing issues  
✅ **Health Monitoring**: Comprehensive health checks with database and cache status  
✅ **Redis Caching**: High-performance caching for dashboard queries  
✅ **Web Portal**: Modern frontend dashboard for data visualization  
✅ **Log Management**: Configured log rotation and structured logging  
✅ **Resource Limits**: Container resource constraints for stability  
✅ **Backup Support**: Built-in data backup and restore commands  
✅ **Monitoring UI**: Kafka UI for real-time system observability  
✅ **Multi-Service Architecture**: Collector, Processor, API, and Portal services  

## Development Workflow

For development environments, use the standard Docker Compose commands:

```bash
# Development mode (builds from source)
docker-compose up -d --build

# View development logs
docker-compose logs -f

# Stop development
docker-compose down

# Portal development shortcuts
make portal-dev     # Start portal in development mode
make dev-up         # Build and start with logs
```

## Docker Images

The system uses the following Docker images:

- **Collector**: `mktowett/edge_telemetry_collector:v1.0.1`
- **Processor**: `mktowett/edge_telemetry_processor:v1.0.1`
- **API**: `mktowett/edge_telemetry_api:v1.0.1`
- **Portal**: `mktowett/edgerum-portal:latest`
- **Kafka**: `confluentinc/cp-kafka:7.4.0`
- **Zookeeper**: `confluentinc/cp-zookeeper:7.4.0`
- **Redis**: `redis:7-alpine`
- **Kafka UI**: `provectuslabs/kafka-ui:latest`

## Security Considerations

- Database credentials are stored in environment files (not in Docker Compose)
- Services communicate through isolated Docker networks
- Only necessary ports are exposed to the host
- Log rotation prevents disk space issues
- Redis is only accessible within the Docker network (except for debugging)
- Portal connects to API backend through internal Docker network

## System Requirements

- **Memory**: Minimum 4GB RAM recommended (increased for Redis, API, and Portal)
- **Storage**: At least 20GB free space for Docker images, logs, and cache
- **Network**: Access to MSSQL database server
- **Ports**: 8001, 8002, 8003, 8004, 8080, 6379 available on host

## Database Schema

The system uses a single shared database that both the processor and API access for storing and querying telemetry data.

Ensure the database is accessible with the configured credentials in `configs/processor-config.env`.

## Support

For issues and questions:
1. Check the troubleshooting section above
2. Review logs with `make prod-logs`
3. Verify configuration with `make config-check`
4. Use `make health-detailed` for comprehensive status
5. Test individual services with `make test-api`, `make test-portal`, or `make test-deployment`

## Quick Access

```bash
# Access the main dashboard
make portal-open

# Or manually open: http://localhost:8004
```

---

**Quick Start Summary:**
```bash
git clone https://github.com/NCG-Africa/EdgeTelemetryDeployment.git
cd EdgeTelemetryDeployment
cp configs/processor-config.env.example configs/processor-config.env
nano configs/processor-config.env  # Configure your database
make prod-deploy
make portal-open  # Open dashboard in browser
```

