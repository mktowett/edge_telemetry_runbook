# Port Reference Guide

## EdgeTelemetryDeployment (Production)

### External Services (Internet Accessible)
| Service | Host Port | Container Port | Purpose | Access Level |
|---------|-----------|----------------|---------|--------------|
| **EdgeTelemetry Collector** | 8001 | 8000 | Data collection API | External |
| **EdgeTelemetry API** | 8003 | 8000 | Dashboard API | External |
| **EdgeRum Portal** | 8004 | 8004 | Web dashboard | External |

### Internal Services (Docker Network Only)
| Service | Host Port | Container Port | Purpose | Access Level |
|---------|-----------|----------------|---------|--------------|
| **EdgeTelemetry Processor** | 8002 | 8000 | Data processing service | Internal |
| **Kafka UI** | 8080 | 8080 | Kafka management | Internal |
| **Redis Cache** | 6379 | 6379 | Caching service | Internal |

### Infrastructure Services (Internal Only)
| Service | Container Port | Purpose |
|---------|----------------|---------|
| **Kafka** | 29092 | Message broker |
| **Zookeeper** | 2181 | Kafka coordination |

## Development Environments

### EdgeTelemetryCollector (Development)
- **Zookeeper**: 2183:2181
- **Kafka**: 9094:9092, 9103:9101
- **Collector**: 8004:8000
- **Kafka UI**: 8082:8080

### EdgeTelemetryProcessor (Development)
- **Zookeeper**: 2184:2181
- **Kafka**: 9095:9092, 9104:9101
- **Processor**: 8005:8000
- **Kafka UI**: 8083:8080

### EdgeTelemetryAPI (Development)
- **Redis**: 6380:6379
- **Dashboard API**: 8006:8000

## Production Domain Configuration

### Required DNS Records
Configure the following domains to point to your server:

| Domain | Port | Service | Description |
|--------|------|---------|-------------|
| `telemetry-collector.yourdomain.com` | 8001 | Collector | Data ingestion endpoint |
| `telemetry-dashboard.yourdomain.com` | 8004 | Portal | User dashboard |
| `telemetry-api.yourdomain.com` | 8003 | API | Dashboard API (optional direct access) |

### SSL/TLS Configuration
For production deployment with HTTPS:
- Port 443 → 8001 (Collector with SSL termination)
- Port 443 → 8003 (API with SSL termination)
- Port 443 → 8004 (Portal with SSL termination)

## Usage Examples

### Production Deployment
```bash
cd EdgeTelemetryDeployment
make prod-deploy

# Access URLs:
# - Portal: http://localhost:8004
# - Collector: http://localhost:8001  
# - API: http://localhost:8003
# - Kafka UI: http://localhost:8080 (internal)

# With custom domains:
# - Portal: https://telemetry-dashboard.yourdomain.com
# - Collector: https://telemetry-collector.yourdomain.com
# - API: https://telemetry-api.yourdomain.com
```

### Development Mode
```bash
cd EdgeTelemetryDeployment
docker-compose up -d --build

# Access same ports as production for development
```

### Individual Service Development

#### Collector Development Only
```bash
cd EdgeTelemetryCollector
docker-compose up -d --build
# Access:
# - Collector: http://localhost:8004
# - Kafka UI: http://localhost:8082
```

#### Processor Development Only
```bash
cd EdgeTelemetryProcessor
docker-compose up -d --build
# Access:
# - Processor: http://localhost:8005
# - Kafka UI: http://localhost:8083
```

#### Dashboard API Development Only
```bash
cd EdgeTelemetryAPI
docker-compose up -d --build
# Access:
# - Dashboard API: http://localhost:8006
# - Redis: localhost:6380
```

## Health Check Endpoints

### Production System
```bash
curl http://localhost:8001/health  # Collector
curl http://localhost:8002/health  # Processor  
curl http://localhost:8003/health  # Dashboard API
curl http://localhost:8004/health  # Portal (or GET /)
```

### Development Services
```bash
curl http://localhost:8004/health  # Collector dev
curl http://localhost:8005/health  # Processor dev
curl http://localhost:8006/health  # Dashboard API dev
```

### Using Make Commands
```bash
make health              # Quick health check
make health-detailed     # Detailed health with database status
make test-portal        # Test portal specifically
make test-api           # Test API endpoints
```

## Firewall Configuration

### Inbound Rules (Production)
| Port | Protocol | Source | Purpose |
|------|----------|--------|---------|
| 8001 | TCP | Internet | Data collection |
| 8003 | TCP | Internet | API access |
| 8004 | TCP | Internet | Dashboard access |
| 8080 | TCP | Internal network | Kafka UI (optional) |
| 22 | TCP | Admin networks | SSH access |

### Outbound Rules (Production)
| Port | Protocol | Destination | Purpose |
|------|----------|-------------|---------|
| 1433 | TCP | SQL Server | Database connection |
| 80/443 | TCP | Internet | Updates/registries |
| 53 | UDP | DNS servers | Name resolution |

## Container Names Reference

### Production Containers
- **telemetry-collector** - Data collection service
- **telemetry-processor** - Data processing service  
- **telemetry-api** - Dashboard API service
- **edgerum-portal** - Web portal frontend
- **telemetry-redis** - Redis cache
- **telemetry-kafka** - Kafka message broker
- **telemetry-zookeeper** - Zookeeper coordination
- **telemetry-kafka-ui** - Kafka management UI

### Development Containers
- **collector-*** - Collector development
- **processor-*** - Processor development
- **api-*** - API development
- **kafka-collector**, **kafka-processor** - Service-specific Kafka instances
- **zookeeper-collector**, **zookeeper-processor** - Service-specific Zookeeper

## Quick Access Commands

### Open Services in Browser
```bash
make portal-open        # Opens portal at http://localhost:8004
```

### Direct URLs
```bash
# Production endpoints
open http://localhost:8004    # Portal dashboard
open http://localhost:8001    # Collector API docs
open http://localhost:8003    # Dashboard API docs  
open http://localhost:8080    # Kafka UI
```

### Service Management
```bash
# Restart specific services
make prod-restart-api      # Restart API only
make prod-restart-portal   # Restart portal only
make prod-restart-redis    # Restart Redis only

# View specific logs
make prod-logs-portal     # Portal logs
make prod-logs-api        # API logs
make prod-logs-collector  # Collector logs
```

## Port Conflicts Resolution

If you encounter port conflicts, you can modify `docker-compose.prod.yml`:

```yaml
# Example: Change collector from 8001 to 8011
services:
  telemetry-collector:
    ports:
      - "8011:8000"  # Change host port only
```

Common alternative ports:
- **8001** → 8011, 8021, 8031
- **8003** → 8013, 8023, 8033  
- **8004** → 8014, 8024, 8034
- **8080** → 8081, 8090, 8180

## Network Architecture

```
Internet → [Reverse Proxy/Load Balancer] → EdgeTelemetry Services
    ↓
Port 80/443 → 8001 (Collector)
Port 80/443 → 8003 (API)  
Port 80/443 → 8004 (Portal)
    ↓
Internal Docker Network:
- Kafka: 29092
- Zookeeper: 2181
- Redis: 6379
- All services communicate internally
```

## Security Notes

- **External ports** (8001, 8003, 8004) should be behind SSL/TLS in production
- **Internal ports** (8002, 8080, 6379) are only accessible within Docker network
- **Kafka UI** (8080) should be restricted to admin networks only
- **Database** connection (1433) must allow access from Docker containers

## Troubleshooting

### Port Already in Use
```bash
# Check what's using a port
sudo netstat -tulpn | grep :8001

# Kill process using port
sudo kill -9 $(sudo lsof -t -i:8001)
```

### Service Not Responding
```bash
# Check container status
docker ps | grep telemetry

# Check container logs
make prod-logs-[service-name]

# Restart specific service
docker compose -f docker-compose.prod.yml restart [service-name]
```